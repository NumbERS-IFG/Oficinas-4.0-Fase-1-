import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import Form from '../components/formCadastro';


export default function Cadastro() {
  return (
    <>
    <Form/>
    </>
  );
}

